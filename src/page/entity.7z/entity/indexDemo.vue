<template>
  <div>
    <router-view></router-view>
  </div>
</template>
<script>
  import { Polymesh } from "@polymeshassociation/polymesh-sdk";
  import { BrowserExtensionSigningManager } from "@polymeshassociation/browser-extension-signing-manager";
  export default {
    data() {
      return {
        api: null,
      };
    },
    // provide: {
    //   api: this.api,
    // },
    // 父组件

    provide() {
      return {
        apiFun: () => this.api,
      };
    },
    methods: {
      async run() {
        console.log(1);
        const signingManager = await BrowserExtensionSigningManager.create({
          appName: "Demo",
          extensionName: "polywallet",
        }); // The Polymesh wallet extension will ask the user to authorize MY_APP_NAME for access
        console.log(2);
        const polyClient = await Polymesh.connect({
          nodeUrl: "wss://testnet-rpc.polymesh.live",
          signingManager,
          middleware: {
            link: "https://testnet-graphql.polymesh.live",
            key: "deprecated",
          },
        });
        console.log("链接：", polyClient);
        this.api = polyClient;
        window.fn = async (fun, str) => {
          window[str] = await fun;
        };
        window.api = this.api;
      },
    },
    mounted() {
      this.run();
    },
  };
</script>
