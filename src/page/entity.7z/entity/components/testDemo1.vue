<style scoped>
.page {
  width: 100%;
  display: flex;
  flex-flow: row nowrap;
}
.page .left {
  width: 460px;
  flex: none;
  min-height: 500px;
  border-right: solid gray 1px;
  margin-right: 10px;
  padding-right: 6px;
}

.page .right {
  flex: auto;
}
.page .right .content {
  display: flex;
  flex-flow: row nowrap;
  justify-content: center;
}
</style>
<style>
.page .ivu-select-dropdown {
  max-height: 450px;
}

.jv-node {
  font-size: 14px;
  padding: 3px 5px 3px 20px;
  border-left: 1px solid rgb(235, 235, 235);
}
.open {
  color: rgb(88, 110, 117);
}
.jv-string {
  color: rgb(203, 75, 22);
}
.jv-key {
  margin-right: 5px;
}
.jv-node.jv-key-node {
  margin-left: 6px;
}
.jv-code > .jv-node {
  padding-left: 5px;
  border-left: none;
}
.jv-node.toggle {
  margin-left: 5px !important;
}
.jv-container .jv-code {
  padding-left: 0px;
}
</style>
<template>
  <div style="width: 98%;margin: 0 auto;text-align:left;">
    <div class="page">
      <div class="left">
        资产： <Select v-model="ticker"
                placeholder="名下的资产ticker"
                style="width:35%;margin-right:6px;">
          <Option v-for="item in assetsList"
                  :value="item.ticker"
                  :key="item.ticker"
                  :label="item.ticker ">
          </Option>
        </Select>
        <Input v-model="ticker"
               style="width:30%;margin-right:6px;"
               placeholder="任意资产ticker" />
        <Button type="primary"
                @click="getAssetsList"
                :disabled="!api">重新获取</Button>
        <Tree :data="data"
              @on-select-change="selectNode"
              ref="tree"></Tree>
        <div style="margin-top:12px;margin-bottom:6px;display:flex;justify-content: space-between;align-items: center;">
          <span>实体数据</span>
          <div v-show="currentEntityTypeIsArr || typeof getEntityFun==='function'"
               style="display:flex;justify-content: space-between;align-items: center;">
            <span>选择第几条实体数据：</span>
            <Select v-model="number"
                    style="width:120px;"
                    @on-change="changeNumber">
              <Option v-for="item in currentEntityTypeIsLengthArr"
                      :key="item"
                      :value="item"
                      :label="item"></Option>
            </Select>
          </div>
        </div>
        <json-viewer :value="currentEntity"
                     expanded
                     :expand-depth="1"
                     copyable
                     boxed
                     sort></json-viewer>
      </div>
      <div class="right">
        <div style="margin-bottom:6px;">
          <span style="font-size:18px;font-weight:700;"> 当前实体：</span> {{ selectedObj.title || '待选' }}
          <span style="font-size:18px;font-weight:700;margin-left:20px;">方法：</span>{{ selectFun || '待选' }}
        </div>
        <div class="content">
          <Button type="primary"
                  @click="executionMethod"
                  :disabled="!selectFun"
                  style="flex:none;margin: 0;">执行方法</Button>
          <Select v-model="selectFun"
                  style="flex:auto;margin-left:6px;"
                  @on-change="changeFun">
            <Option v-for="item in selectedObj.methods"
                    :value="item.value"
                    :key="item.value"
                    :title="item.description"
                    :label="item.title ">
              <span>{{ item.title }}</span>
              <span v-show="item.available"
                    style="margin-left:16px;">
                <Icon type="md-checkmark-circle"
                      color="#19be6b"
                      size="18" />
              </span>
            </Option>
          </Select>
        </div>

        <div style="margin-top:12px;margin-bottom:6px;"> 是否入参：
          <i-Switch v-model="isParams"
                    :disabled="this.currentFunObj.isOptionRequired">
            <span slot="open">是</span>
            <span slot="close">否</span>
          </i-Switch>
        </div>
        <div>
          <Input v-model="paramsObj"
                 type="textarea"
                 :rows="4"
                 placeholder="Enter something..." />
        </div>
        <div style="margin-top:12px;margin-bottom:6px;">
          结果：
        </div>
        <json-viewer :value="result"
                     expanded
                     :expand-depth="2"
                     copyable
                     boxed
                     sort></json-viewer>

      </div>
    </div>
  </div>
</template>
<script>
import BigNumber from 'bignumber.js';
import data from "../../../components/entity";
export default {
  components: {},
  data () {
    return {
      ticker: '',
      data: this.setDate(),
      selectFun: '',
      selectedObj: {},
      result: '无数据',
      currentEntity: '暂无数据', // 当前实体数据
      currentEntityTypeIsArr: false, // 当前实体是否是数组
      currentEntityTypeIsLengthArr: [], // 实体为数组时，长度数组
      number: '0', // 当实体是数组，选择第几条数据
      // selectEntity:null, // 当实体是数组，
      currentFunObj: {}, // 当前方法对象
      paramsObj: null,
      isParams: false, // 是否入参
      assetsList: [],
      getEntityFun: null
    };
  },
  computed: {
    api () {
      const api = this.apiFun();
      return api;
    },
  },
  watch: {
    api: {
      deep: true,
      handler () {
        this.getAssetsList()
      }
    }
  },
  methods: {
    changeNumber (val) {
      if (typeof this.getEntityFun === 'function') {
        this.currentEntity = this.getEntityFun(val)
        window.source = this.currentEntity;
        console.log(`当前实体是通过数组得到的，默认取下标为 0 拿到的实体，执行方法，获取下标为 ${val} 的数据：`, this.currentEntity)
      }
    },
    setDate () {
      const f = (arr) => {
        arr.forEach(item => {
          // { root, data, node }
          item.render = (h, { data }) => {
            return h('span', {}, [
              h('span', {
                attrs: {
                  title: data.description,//title显示内容
                },
              }, data.title),
              h('Icon', {
                props: {
                  type: 'md-checkmark-circle'
                },
                style: {
                  marginLeft: '8px',
                  fontSize: '18px',
                  color: "#19be6b",
                  display: this.selectedObj.value === data.value ? 'inline-block' : 'none'
                }
              })
            ])
          }
          if (item.children.length > 0) {
            f(item.children)
          }
        })
      }
      f(data)
      return data;
    },
    async getAssetsList () {
      if (!this.api) {
        return;
      }
      this.assetsList = await this.api.assets.getAssets()
      this.ticker = this.assetsList[0].ticker
    },
    changeFun (val) {
      if (!val) {
        return;
      }
      this.selectFun = val;
      this.currentFunObj = this.selectedObj.methods.filter((item) => item.value === val)[0]
      console.log('当前选中方法：', this.currentFunObj)
      this.paramsObj = JSON.stringify(this.currentFunObj.options, false, 2)
      this.isParams = this.currentFunObj.isOptionRequired || false
    },
    async executionMethod () { // 执行方法
      console.log('执行方法：', this.selectFun)
      this.result = '方法执行中，请稍后...'
      let result;
      let currentEntity;
      // 当前实体为数组的时候，需要选择其中一条
      if (this.currentEntityTypeIsArr) {
        currentEntity = this.currentEntity[parseInt(this.number)];
      } else {
        currentEntity = this.currentEntity;
      }
      if (this.isParams) {
        const params = JSON.parse(this.paramsObj)
        if (params instanceof Array) { // 数组
          params.claims.forEach(item => {
            for (let key in item) {
              if (key === 'expiry' && item[key]) {
                item[key] = new Date(item[key])
              }
              if ((key === 'id' || key === 'size' || key === 'amount' || key === 'venueId' || key === 'percentage' || key === 'perShare' || key === 'maxAmount' || key === 'portfolioId' || key==='portfolio') && typeof params[key] === 'number') {
                params[key] = new BigNumber(params[key])
              }
            }
          })
        } else {
          for (let key in params) {
            if (key === 'expiry' && params[key]) {
              params[key] = new Date(params[key])
            }
            if ((key === 'id' || key === 'size' || key === 'amount' || key === 'venueId' || key === 'percentage' || key === 'perShare' || key === 'maxAmount' || key === 'portfolioId' || key==='portfolio') && typeof params[key] === 'number') {
              params[key] = new BigNumber(params[key])
            }
          }
        }
        console.log('入参：', params)
        result = await currentEntity[this.selectFun](params)
      } else {
        result = await currentEntity[this.selectFun]()
      }
      console.log('查询结果：', result)
      if(result===null){
        this.result = '没有查到数据，结果为null';
      }else if(typeof result === 'string'){
        this.result = result;
      } else if (typeof result === 'boolean') {
        this.result = result;
      } else if ('hasRun' in result && !result.hasRun) {
        console.log('开始签名。。。', result)
        const runResult = await result.run()
        console.log('签名成功！', runResult)
        this.result = runResult || '执行成功';
      } else {
        this.result = result || '暂无数据';
      }
      window.result = result
    },
    selectNode ([obj]) {
      console.log('selectNode:', obj)
      console.log('获取被选中节点：', this.$refs.tree.getSelectedNodes())
      if (!obj) {
        if (JSON.stringify(this.selectedObj) === '{}') {
          this.$Message.warning('请重新选择实体！');
          return;
        }
        obj = this.selectedObj
      }
      this.selectedObj = obj
      this.selectFun = ''
      this.getCurrentEntity()
    },
    async getCurrentEntity () {
      if (!this.api) {
        this.$Message.warning('请稍后再试，登录中....');
        return;
      }
      if (!this.ticker) {
        await this.getAssetsList()
      }
      this.currentEntity = '实体查询中...'
      console.log(this.api)
      let source = await this.selectedObj.source({ api: this.api, ticker: this.ticker, number: parseInt(this.number) })
      this.currentEntityTypeIsArr = source instanceof Array;
      if (this.currentEntityTypeIsArr) { // 数组 查询回来的实体数据是数组
        const arr = []
        for (let i = 0; i < source.length; i++) {
          arr.push(i + '')
        }
        this.currentEntityTypeIsLengthArr = arr;
        this.number = '0'
      }
      if (source && typeof source === 'object' && 'fn' in source && typeof source.fn === 'function' && typeof source.totalLength === 'number') {
        const arr = []
        for (let i = 0; i < source.totalLength; i++) {
          arr.push(i + '')
        }
        this.currentEntityTypeIsLengthArr = arr;
        this.getEntityFun = source.fn;
        let currentEntity = this.getEntityFun(parseInt(this.number))
        if (currentEntity instanceof Date) {
          console.log('返回的实体是Date类型：', currentEntity)
          this.currentEntity = JSON.stringify(currentEntity);
        } else {
          this.currentEntity = currentEntity;
        }
        window.source = currentEntity;
        console.log('执行方法,拿到当前实体：', this.selectedObj.title, currentEntity)
        return;
      }
      if (source instanceof Date) {
        source = JSON.stringify(source)
      }
      this.currentEntity = source
      window.source = source
      console.log('执行方法,拿到当前实体：', this.selectedObj.title, source)
      this.getEntityFun = null;
    },
    action () {
      const account = this.api.accountManagement.getSigningAccount();
      console.log("address: ", account.address);
    },
  },
  inject: ["apiFun"],
  mounted () {
    if (!this.ticker) {
      this.getAssetsList()
    }
  }
};
</script>
